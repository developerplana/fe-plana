import Link from "next/link";
import Image from "next/image";
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";

export default function Home() {
  const settings = {
    dots: true,
    infinite: true,
    speed: 500,
    slidesToShow: 1,
    slidesToScroll: 1,
    autoplay: true,
    autoplaySpeed: 3000,
  };

  return (
    <main>
      <div className="section py-5 px-4 px-xl-0">
        <div className="container-xl">
          <div className="row hero gy-0 gy-lg-5">
            <div className="col-12 col-lg-7 col-xl-6">
              <h1 className="display-2 fw-bold">
                BE IN THE PLANA.
                <br />
                GO FORWARD WITH COMFORT.
              </h1>
              <p className="d-block d-lg-none">
                Saddle up! Plana is the mustang of advertising film production, delivering fast, creative solutions for local and international clients. No project is too wild—ride toward success with Plana!
              </p>
            </div>
            <div className="col-12 col-lg-5 col-xl-6 pt-lg-5 pt-0">
              <p className="pt-lg-5 d-none d-lg-block">
                Saddle up! Plana is the mustang of advertising film production, delivering fast, creative solutions for local and international clients. No project is too wild—ride toward success with Plana!
              </p>
            </div>
            <div className="col-12">
              <Link href="#anti-hero" className="text-decoration-none">
                <div id="scroll-down-animation" className="mx-0">
                  <span className="mouse">
                    <span className="move"></span>
                  </span>
                </div>
              </Link>
            </div>
          </div>
        </div>

        <Slider {...settings}>
          <div>
            <Image
              src="https://via.placeholder.com/600x300?text=Slide+1"
              alt="Slide 1"
              width={600}
              height={300}
              unoptimized
            />
          </div>
          <div>
            <Image
              src="https://via.placeholder.com/600x300?text=Slide+2"
              alt="Slide 2"
              width={600}
              height={300}
              unoptimized
            />
          </div>
          <div>
            <Image
              src="https://via.placeholder.com/600x300?text=Slide+3"
              alt="Slide 3"
              width={600}
              height={300}
              unoptimized
            />
          </div>
        </Slider>

        <ul className="slideshow">
          <li></li>
          <li></li>
          <li></li>
          <li></li>
          <li></li>
        </ul>
      </div>

      {/* Other sections remain unchanged, but ensure all image srcs are either used with <Image> and domains whitelisted in next.config.js, or marked with unoptimized */}
    </main>
  );
}
