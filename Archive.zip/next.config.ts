import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  images: {
    domains: ["via.placeholder.com", "placehold.co","plana.vision","dev.plana.vision","www.dropbox.com"],
  },
};

export default nextConfig;
